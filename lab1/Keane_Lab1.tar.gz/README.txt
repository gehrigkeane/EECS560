Gehrig Keane
2727430
EECS 560 LAB, Monday
Lab 1

Notes: (In Github Markdown)
* The formatting is very similar to the sample I/O provided in the assignment page, but additions were made for content not presented or ambiguous interactions.

* Input is sterilized and only intergers between 1 and 4 are acceptable input (Dialog's exits as reminders)

* Filename is hardcoded as Directory crawling without strings is cumbersome

* Additionally, due to the exclusion of strings gcc warnings have been suppressed for the LinkedList class due to C99 char* return casting and annoying deprecation warnings