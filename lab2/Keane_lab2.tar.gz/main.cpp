/*
*	@file	: main.cpp
*	@author	: Gehrig Keane
*	@date	: 2015.08.31
*	Purpose	: provide main functionality
*/

#include <iostream>
#include "BTQ.h"

int main(int argc, char** argv)
{
	//Build Tree
	BinaryTree* tree = new BinaryTree();
	tree->build();

	//Print, find largest #, and find # of leaves
	tree->print();
	std::cout << std::endl << "Largest: " << tree->largest();
	std::cout << std::endl << "Leaves: " << tree->leaves() << std::endl;

	delete tree;
	return 0;
}
