/*
*	@file	: Leaf.h
*	@author	: Gehrig Keane
*	@date	: 2015.08.31
*	Purpose	: Header file for the Leaf class
*/

#ifndef LEAF_H
#define LEAF_H

#include <iostream> /** NULL */

class Leaf
{
	public:
	//Constructors-Destructors
	Leaf();
	Leaf(int value);
	Leaf(int value, Leaf* next);

	//Accessors
	int getValue();
	Leaf* getNext();
	Leaf* getLeft();
	Leaf* getRight();

	//Mutators
	void setValue(int value);
	void setNext(Leaf* next);
	void setLeft(Leaf* left);
	void setRight(Leaf* right);

	private:
	Leaf* m_next;
	Leaf* m_left;
	Leaf* m_right;
	int m_value;
};
#include "Leaf.hpp"
#endif
