/*
*	@file	: Leaf.hpp
*	@author	: Gehrig Keane
*	@date	: 2015.08.31
*	Purpose	: leaf implementation
*/

Leaf::Leaf()
{
	m_value = 0;
	m_next = nullptr;
	m_left = nullptr;
	m_right = nullptr;
}//Leaf Default Constructor

Leaf::Leaf(int value)
{
	m_value = value;
	m_next = nullptr;
	m_left = nullptr;
	m_right = nullptr;
}//Leaf value constructor

Leaf::Leaf(int value, Leaf* next)
{
	m_value = value;
	m_next = next;
	m_left = nullptr;
	m_right = nullptr;
}//Leaf value constructor

int Leaf::getValue()
{
	return m_value;
}//getValue - accessor

Leaf* Leaf::getNext()
{
	return m_next;
}//getNext - accessor

Leaf* Leaf::getLeft()
{
	return m_left;
}//getLeft - accessor

Leaf* Leaf::getRight()
{
	return m_right;
}//getRight - accessor

void Leaf::setValue(int value)
{
	m_value = value;
}//setValue - mutator

void Leaf::setNext(Leaf* next)
{
	m_next = next;
}//setNext - mutator

void Leaf::setLeft(Leaf* left)
{
	m_left = left;
}//setLeft - mutator

void Leaf::setRight(Leaf* right)
{
	m_right = right;
}//setRight - mutator
