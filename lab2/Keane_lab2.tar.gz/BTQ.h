/*
*	@file	: BTQ.h
*	@author	: Gehrig Keane
*	@date	: 2015.08.31
*	Purpose	: Header file for the BinaryTree class
*/

#ifndef BINARYTREE_H
#define BINARYTREE_H

#include <stdio.h>
#include <stdlib.h>
#include <iostream>	/** NULL */
#include "Leaf.h"	/** Leaf implementation **/

class BinaryTree
{
	public:
	//Constructors-Destructors
	BinaryTree();
	~BinaryTree();

	//Lab Required Functions - public
	void build();
	int largest();
	int leaves();
	void print();
	
	//Helper Functions - public
	int height(Leaf* leaf);

	private:
	//Lab Required Functions - private
	int largest(Leaf* subtree, int val) const;
	int leaves(Leaf* leaf) const;	
	void print(Leaf* subtree) const;

	///Helper Functions - private
	void clear();
	void clear(Leaf* subtree);
	void deleteTree(Leaf* subtree);
	void dequeue();
	void enqueue(Leaf* leaf);
	void setQueue(Leaf* leaf);

	Leaf* m_root;
	Leaf* queue;

};
#include "BTQ.hpp"
#endif
