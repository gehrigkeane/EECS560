/*
*	@file	: BTQ.hpp
*	@author	: Gehrig Keane
*	@date	: 2015.08.31
*	Purpose	: provides functionality for the BinaryTree class
*/

#include <string.h>
#include <cstdlib>
#include "List.h"

BinaryTree::BinaryTree()
{
	m_root = nullptr;
	queue = nullptr;
}//Default Constructor

BinaryTree::~BinaryTree()
{
	deleteTree(m_root);
}//Default Destructor

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//				Helper Functions
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void BinaryTree::clear()
{
	clear(m_root);
}//clear - call function

void BinaryTree::clear(Leaf* subtree)
{
	if ( subtree == nullptr )
		return;
	clear(subtree->getLeft());
	subtree->setNext(nullptr);
	clear(subtree->getRight());
}//clear - removes all traces of the queue from the leaves

void BinaryTree::deleteTree(Leaf* subtree)
{
	if ( subtree == nullptr ) 
		return;
	if ( subtree->getLeft() != nullptr )
		deleteTree( subtree->getLeft() );
	if ( subtree->getRight() != nullptr )
		deleteTree( subtree->getRight() );

	delete subtree;
	return;
}//deleteTree - used to improve destructor aesthetic (recycled)

void BinaryTree::dequeue()
{
	if ( queue != nullptr )
		queue=queue->getNext();
}//dequeue - remove leaf from queue

void BinaryTree::enqueue(Leaf* leaf)
{
	Leaf* temp = queue;
	if ( (temp->getNext()) != nullptr )
	{
		for(;(temp->getNext())!=nullptr;temp=temp->getNext());
		temp->setNext(leaf);
	}//if - make sure there is a node in the list
	else
		temp->setNext(leaf);
}//enqueue - push leaf into the queue

int BinaryTree::height(Leaf* leaf)
{
	if ( leaf == nullptr )
		return -1;

	int l = height(leaf->getLeft());
	int r = height(leaf->getRight());

	if ( l > r )
		return l + 1;
	else
		return r + 1;
}//height - find height of binary tree (recycled)

void BinaryTree::setQueue(Leaf* leaf)
{
	queue = leaf;
}//setQueue - set queue head

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//				Lab Required Functions
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void BinaryTree::build()
{
	char line[1024];
	char* tok;
	FILE* fp = fopen("data.txt","r");

	//Simple Linked List instantiation
	List* newlist = new List();

	while (fgets(line, sizeof line, fp) != NULL)
	{
		tok = strtok (line," ,.-");
		while (tok != nullptr)
		{
			//~~~~~~~~~~Build Simple Linked List Here~~~~~~~~~~
			//Assumes good integer values from file
			newlist->addBack(std::atoi(tok));

			tok = strtok (NULL, " ,.-");
		}//while - the line no longer has integers
	}//while - lines left in the file

	//root = first element
	m_root = new Leaf(newlist->pop());

	//current = queue = root
	queue = m_root;

	while( !newlist->isEmpty() )
	{
		int val1 = newlist->pop();
		int val2 = newlist->pop();

		if ( val1 != 0 )
		{
			Leaf* temp1 = new Leaf(val1);
			queue->setLeft(temp1);
			enqueue(temp1);
		}//if - attach left leaf

		if ( val2 != 0 )
		{
			Leaf* temp2 = new Leaf(val2);
			queue->setRight(temp2);
			enqueue(temp2);
		}//if - attach right leaf

		dequeue();
	}//while - there are values left to be built

	fclose(fp);
	delete newlist;
}//build - build binary tree from data.txt

int BinaryTree::largest()
{
	return largest(m_root, 0);
}//largest - call function

int BinaryTree::largest(Leaf* subtree, int val) const
{
	if( subtree == nullptr )
		return val;

	val = largest(subtree->getLeft(), val);

	if ( subtree->getValue() > val )
		val = subtree->getValue();

	val = largest(subtree->getRight(), val);

	return val;
}//largest - find the largest element in the binary tree

int BinaryTree::leaves()
{
	return leaves(m_root);
}//leaves - call function

int BinaryTree::leaves(Leaf* leaf) const
{
	if ( leaf == nullptr )
		return 0;
	if ( leaf->getLeft() == nullptr && leaf->getRight() == nullptr )
		return 1;
	else if ( leaf->getLeft() == NULL && leaf->getRight() == nullptr )
		return leaves(leaf->getRight());
	else if ( leaf->getLeft() == nullptr && leaf->getRight() == NULL )
		return leaves(leaf->getLeft());
	else
		return leaves(leaf->getLeft()) + leaves(leaf->getRight());
}//leaves - find the number of leaves in the binary tree

void BinaryTree::print()
{
	print(m_root);
}//print - call function

void BinaryTree::print(Leaf* subtree) const
{
	if ( subtree == nullptr )
		return;
	print(subtree->getLeft());
	std::cout << subtree->getValue() << " ";
	print(subtree->getRight());
}//print - prints space deliniated inline tree traversal  (recycled)
